# Odoo 17 – School Portal Management

Module: `school_portal_management`

## Features
- Students with automatic academic numbers using an Odoo sequence.
- Parent/guardian linked to `res.partner`.
- Classes, subjects, homework, exams and attendance.
- Teacher and school-manager security groups.
- Parent portal is restricted by `student.parent_id == request.env.user.partner_id`.
- Student portal is restricted by `student.portal_user_id == request.env.user`.
- Homework upload from portal.
- Homework Max grade is 100 
- Exam grades cannot exceed the maximum grade.
- One attendance record per student/day enforced by SQL constraint.
- Absence percentage calculation.
- Daily cron for due-soon homework activities and overdue homework.
- QWeb PDF academic report.
- Arabic RTL portal/report presentation.

## Installation
1. create custom addons directory 
2. Copy `school_portal_management` into an Odoo 17 custom addons directory.
3. Make sure the directory is included in `addons_path`.
4. Restart Odoo.
5. Activate developer mode.
6. Update Apps List.
7. Install **School Portal Management**.

## User setup
### School Teacher
Create an internal Odoo user and add **School Teacher**.
Assign the teacher to classes and subjects. Record rules then restrict backend records to their assigned data.

### School Manager
Create an internal Odoo user and add **School Manager**. This group inherits School Teacher and has unrestricted access to the school models.

### Parent portal
Create a portal user whose partner is the same `res.partner` stored in `school.student.parent_id`. The parent will see only children whose `parent_id` matches the portal user's partner.

### Student portal
Create a portal user and set it on `school.student.portal_user_id`. The student will see only their own homework, attendance and exams.

## Demo Data 
1. ahmed is math teacher 
2. ali is since teacher 
3. shatha and shaima their father is sultan 
4. maram her father is fahd 
5. admin is school manager has access to every thing (group school manager)
6. ahmed and ali hve access only for their students (group school teacher)

## Portal routes
Student:
- `/my/school/homework`
- `/my/school/homework/<homework_id>`
- `/my/school/attendance`
- `/my/school/exams`

Parent:
- `/my/children`
- `/my/children/<student_id>`
- `/my/children/<student_id>/homework`
- `/my/children/<student_id>/attendance`
- `/my/children/<student_id>/exams`
- `/my/children/<student_id>/dashboard`

