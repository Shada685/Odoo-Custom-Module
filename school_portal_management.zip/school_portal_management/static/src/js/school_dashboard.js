/** @odoo-module */

import publicWidget from '@web/legacy/js/public/public_widget';

publicWidget.registry.SchoolDashboard = publicWidget.Widget.extend({
    selector: '#school-dashboard',
    start() {
        this._refreshCards();
        return this._super(...arguments);
    },
    _refreshCards() {
        this.$('.card').each(function () {
            this.classList.add('school-dashboard-card');
        });
    },
});
