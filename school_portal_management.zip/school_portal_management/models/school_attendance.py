from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SchoolAttendance(models.Model):
    _name = 'school.attendance'
    _description = 'School Attendance'
    _order = 'date desc, id desc'

    student_id = fields.Many2one('school.student', required=True, ondelete='cascade')
    class_id = fields.Many2one('school.class', required=True, ondelete='restrict')
    date = fields.Date(required=True, default=fields.Date.context_today)
    state = fields.Selection([
        ('present', 'حاضر'),
        ('absent', 'غائب'),
        ('late', 'متأخر'),
        ('excused', 'بعذر'),
    ], required=True, default='present')
    teacher_id = fields.Many2one('res.users', required=True, default=lambda self: self.env.user, domain=[('share', '=', False)])
    notes = fields.Text()

    @api.constrains('student_id', 'class_id')
    def _check_student_class(self):
        for rec in self:
            if rec.student_id.class_id != rec.class_id:
                raise ValidationError('The attendance student must belong to the selected class.')

    _sql_constraints = [
        ('student_date_unique', 'unique(student_id, date)', 'Attendance for the same student and date already exists.'),
    ]

    @api.model
    def get_absence_rate(self, student):
        total = self.search_count([('student_id', '=', student.id)])
        absent = self.search_count([('student_id', '=', student.id), ('state', '=', 'absent')])
        return (absent / total * 100.0) if total else 0.0
