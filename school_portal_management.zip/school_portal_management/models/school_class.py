from odoo import api, fields, models


class SchoolClass(models.Model):
    _name = 'school.class'
    _description = 'School Class'
    _order = 'academic_year desc, name'

    name = fields.Char(required=True)
    education_stage = fields.Selection([
        ('primary', 'ابتدائي'),
        ('middle', 'متوسط'),
        ('secondary', 'ثانوي'),
    ], string='Education Stage', required=True, default='primary')
    academic_year = fields.Char(string='Academic Year', required=True)
    teacher_id = fields.Many2one('res.users', string='Class Teacher', domain=[('share', '=', False)])
    student_ids = fields.One2many('school.student', 'class_id', string='Students')
    student_count = fields.Integer(compute='_compute_student_count')

    @api.depends('student_ids')
    def _compute_student_count(self):
        for rec in self:
            rec.student_count = len(rec.student_ids)

    _sql_constraints = [
        ('name_year_unique', 'unique(name, academic_year)', 'Class name must be unique within the academic year.'),
    ]
