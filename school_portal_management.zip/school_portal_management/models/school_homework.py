from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SchoolHomework(models.Model):
    _name = 'school.homework'
    _description = 'School Homework'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'due_date desc, id desc'

    title = fields.Char(string='Homework Title', required=True, tracking=True)
    student_id = fields.Many2one('school.student', required=True, ondelete='cascade', tracking=True)
    class_id = fields.Many2one('school.class', required=True, ondelete='restrict', tracking=True)
    subject_id = fields.Many2one('school.subject', required=True, ondelete='restrict', tracking=True)
    teacher_id = fields.Many2one('res.users', required=True, default=lambda self: self.env.user, domain=[('share', '=', False)], tracking=True)
    due_date = fields.Datetime(required=True, tracking=True)
    description = fields.Html()
    state = fields.Selection([
        ('draft', 'مسودة'),
        ('assigned', 'مسند'),
        ('submitted', 'تم التسليم'),
        ('graded', 'تم التصحيح'),
        ('late', 'متأخر'),
    ], default='draft', required=True, tracking=True)
    student_attachment = fields.Binary(string='Student Attachment', attachment=True)
    student_attachment_name = fields.Char()
    grade = fields.Float(string='Grade', digits=(16, 2))
    teacher_notes = fields.Text()
    submitted_at = fields.Datetime(readonly=True)


    @api.onchange('student_id')
    def _onchange_student_id(self):
        for rec in self:
            if rec.student_id:
                rec.class_id = rec.student_id.class_id

    @api.onchange('class_id')
    def _onchange_class_id(self):
        for rec in self:
            if rec.class_id and rec.student_id and rec.student_id.class_id != rec.class_id:
                rec.student_id = False

    @api.constrains('student_id', 'class_id')
    def _check_student_class(self):
        for rec in self:
            if rec.student_id.class_id != rec.class_id:
                raise ValidationError('The homework student must belong to the selected class.')

    @api.constrains('subject_id', 'class_id', 'teacher_id')
    def _check_subject_teacher(self):
        for rec in self:
            if rec.subject_id and rec.subject_id.teacher_id != rec.teacher_id:
                raise ValidationError('The homework teacher must be the subject teacher.')
            if rec.subject_id and rec.class_id not in rec.subject_id.class_ids:
                raise ValidationError('The selected subject is not assigned to this class.')

    @api.constrains('grade')
    def _check_grade(self):
        for rec in self:
            if rec.grade < 0 or rec.grade > 100:
                raise ValidationError('Homework grade must be between 0 and 100.')

    def action_assign(self):
        self.write({'state': 'assigned'})

    def action_mark_late(self):
        self.filtered(lambda r: r.state not in ('submitted', 'graded')).write({'state': 'late'})

    def action_grade(self):
        for rec in self:
            if rec.grade < 0 or rec.grade > 100:
                raise ValidationError('Homework grade must be between 0 and 100.')
        self.write({'state': 'graded'})

    @api.model
    def cron_school_homework(self):
        now = fields.Datetime.now()
        tomorrow = fields.Datetime.add(now, days=1)
        reminder_domain = [
            ('due_date', '>=', now),
            ('due_date', '<=', tomorrow),
            ('state', 'in', ['assigned']),
        ]
        for homework in self.search(reminder_domain):
            existing = self.env['mail.activity'].search([
                ('res_model', '=', self._name),
                ('res_id', '=', homework.id),
                ('activity_type_id', '=', self.env.ref('mail.mail_activity_data_todo').id),
                ('user_id', '=', homework.teacher_id.id),
                ('summary', '=', 'Homework due reminder'),
            ], limit=1)
            if not existing:
                homework.activity_schedule(
                    'mail.mail_activity_data_todo',
                    user_id=homework.teacher_id.id,
                    summary='Homework due reminder',
                    note='Homework is due today or tomorrow.',
                )

        overdue = self.search([
            ('due_date', '<', now),
            ('state', 'in', ['draft', 'assigned']),
        ])
        overdue.action_mark_late()
