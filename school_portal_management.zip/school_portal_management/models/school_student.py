from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SchoolStudent(models.Model):
    _name = 'school.student'
    _description = 'School Student'
    _order = 'name'

    name = fields.Char(string='Student Name', required=True)
    academic_number = fields.Char(string='Academic Number', required=True, copy=False, readonly=True, default='New', index=True)
    parent_id = fields.Many2one('res.partner', string='Parent/Guardian', required=True, ondelete='restrict')
    portal_user_id = fields.Many2one('res.users', string='Student Portal User', domain=[('share', '=', True)], ondelete='set null')
    class_id = fields.Many2one('school.class', string='Class', ondelete='restrict')
    status = fields.Selection([
        ('active', 'نشط'),
        ('suspended', 'موقوف'),
        ('graduated', 'متخرج'),
    ], default='active', required=True)
    enrollment_date = fields.Date(string='Enrollment Date', default=fields.Date.context_today, required=True)
    notes = fields.Text()
    image_1920 = fields.Image(string='Student Image')
    user_partner_id = fields.Many2one(related='portal_user_id.partner_id', string='Portal Partner', store=True, readonly=True)
    teacher_id = fields.Many2one(related='class_id.teacher_id', string='Class Teacher', store=True, readonly=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('academic_number', 'New') == 'New':
                vals['academic_number'] = self.env['ir.sequence'].next_by_code('school.student') or 'New'
        return super().create(vals_list)

    @api.constrains('portal_user_id')
    def _check_portal_user(self):
        for rec in self:
            if rec.portal_user_id and not rec.portal_user_id.share:
                raise ValidationError('The student portal user must be a portal user.')

    _sql_constraints = [
        ('academic_number_unique', 'unique(academic_number)', 'Academic number must be unique.'),
    ]
