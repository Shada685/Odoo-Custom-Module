from odoo import fields, models


class SchoolSubject(models.Model):
    _name = 'school.subject'
    _description = 'School Subject'
    _order = 'name'

    name = fields.Char(required=True)
    teacher_id = fields.Many2one('res.users', string='Teacher', required=True, domain=[('share', '=', False)])
    class_ids = fields.Many2many('school.class', 'school_subject_class_rel', 'subject_id', 'class_id', string='Classes')
    description = fields.Text()
