from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SchoolExam(models.Model):
    _name = 'school.exams'
    _description = 'School Exam'
    _order = 'exam_date desc, id desc'

    name = fields.Char(string='Exam Name', required=True)
    student_id = fields.Many2one('school.student', required=True, ondelete='cascade')
    class_id = fields.Many2one('school.class', required=True, ondelete='restrict')
    subject_id = fields.Many2one('school.subject', required=True, ondelete='restrict')
    exam_date = fields.Date(required=True)
    max_grade = fields.Float(string='Maximum Grade', required=True, default=100)
    student_grade = fields.Float(string='Student Grade')
    teacher_id = fields.Many2one('res.users', required=True, default=lambda self: self.env.user, domain=[('share', '=', False)])
    notes = fields.Text()

    @api.constrains('student_grade', 'max_grade')
    def _check_grades(self):
        for rec in self:
            if rec.max_grade <= 0:
                raise ValidationError('Maximum grade must be greater than zero.')
            if rec.student_grade < 0 or rec.student_grade > rec.max_grade:
                raise ValidationError('Student grade  cannot be less than zero OR exceed the maximum grade.')

    @api.constrains('student_id', 'class_id')
    def _check_student_class(self):
        for rec in self:
            if rec.student_id.class_id != rec.class_id:
                raise ValidationError('The exam student must belong to the selected class.')

    @api.constrains('subject_id', 'class_id', 'teacher_id')
    def _check_subject_teacher(self):
        for rec in self:
            if rec.subject_id.teacher_id != rec.teacher_id:
                raise ValidationError('The exam teacher must be the subject teacher.')
            if rec.class_id not in rec.subject_id.class_ids:
                raise ValidationError('The selected subject is not assigned to this class.')
