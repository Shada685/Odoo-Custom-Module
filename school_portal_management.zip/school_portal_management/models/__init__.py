from . import school_student
from . import school_class
from . import school_exam
from . import school_homework
from . import school_subject
from . import school_attendance