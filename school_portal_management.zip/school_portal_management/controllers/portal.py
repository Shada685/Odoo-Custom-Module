from odoo import http, fields
from odoo.http import request
from werkzeug.exceptions import Forbidden, NotFound


class SchoolPortalController(http.Controller):

    def _student_for_current_user(self, student_id):
        student = request.env['school.student'].sudo().browse(student_id).exists()
        if not student:
            raise NotFound()
        user = request.env.user
        if student.portal_user_id.id == user.id:
            return student
        if student.parent_id.id == user.partner_id.id:
            return student
        raise Forbidden()

    def _student_for_parent(self, student_id):
        student = request.env['school.student'].sudo().browse(student_id).exists()
        if not student:
            raise NotFound()
        if student.parent_id.id != request.env.user.partner_id.id:
            raise Forbidden()
        return student

    def _student_for_student(self):
        student = request.env['school.student'].sudo().search([
            ('portal_user_id', '=', request.env.user.id)
        ], limit=1)
        if not student:
            raise Forbidden()
        return student

    @http.route('/my/school/homework', type='http', auth='user', website=True)
    def student_homework(self, **kw):
        student = self._student_for_student()
        homework = request.env['school.homework'].sudo().search([('student_id', '=', student.id)], order='due_date desc')
        return request.render('school_portal_management.portal_student_homework', {'student': student, 'homework': homework})

    @http.route('/my/school/homework/<int:homework_id>', type='http', auth='user', website=True, methods=['GET', 'POST'])
    def student_homework_detail(self, homework_id, **post):
        student = self._student_for_student()
        homework = request.env['school.homework'].sudo().browse(homework_id).exists()
        if not homework or homework.student_id.id != student.id:
            raise Forbidden()
        if request.httprequest.method == 'POST':
            upload = request.httprequest.files.get('attachment')
            if upload and upload.filename:
                now = fields.Datetime.now()
                state = 'submitted' if homework.due_date >= now else 'late'
                homework.write({
                    'student_attachment': upload.read(),
                    'student_attachment_name': upload.filename,
                    'submitted_at': now,
                    'state': state,
                })
        return request.render('school_portal_management.portal_student_homework_detail', {'student': student, 'homework': homework})

    @http.route('/my/school/attendance', type='http', auth='user', website=True)
    def student_attendance(self, **kw):
        student = self._student_for_student()
        records = request.env['school.attendance'].sudo().search([('student_id', '=', student.id)], order='date desc')
        rate = request.env['school.attendance'].sudo().get_absence_rate(student)
        return request.render('school_portal_management.portal_student_attendance', {'student': student, 'records': records, 'absence_rate': rate})

    @http.route('/my/school/exams', type='http', auth='user', website=True)
    def student_exams(self, **kw):
        student = self._student_for_student()
        exams = request.env['school.exams'].sudo().search([('student_id', '=', student.id)], order='exam_date desc')
        return request.render('school_portal_management.portal_student_exams', {'student': student, 'exams': exams})

    @http.route('/my/children', type='http', auth='user', website=True)
    def children(self, **kw):
        children = request.env['school.student'].sudo().search([('parent_id', '=', request.env.user.partner_id.id)], order='name')
        return request.render('school_portal_management.portal_children', {'children': children})

    @http.route('/my/children/<int:student_id>', type='http', auth='user', website=True)
    def child_detail(self, student_id, **kw):
        student = self._student_for_parent(student_id)
        return request.render('school_portal_management.portal_child_detail', {'student': student})

    @http.route('/my/children/<int:student_id>/homework', type='http', auth='user', website=True)
    def child_homework(self, student_id, **kw):
        student = self._student_for_parent(student_id)
        records = request.env['school.homework'].sudo().search([('student_id', '=', student.id)], order='due_date desc')
        return request.render('school_portal_management.portal_child_homework', {'student': student, 'homework': records})

    @http.route('/my/children/<int:student_id>/attendance', type='http', auth='user', website=True)
    def child_attendance(self, student_id, **kw):
        student = self._student_for_parent(student_id)
        records = request.env['school.attendance'].sudo().search([('student_id', '=', student.id)], order='date desc')
        rate = request.env['school.attendance'].sudo().get_absence_rate(student)
        return request.render('school_portal_management.portal_child_attendance', {'student': student, 'records': records, 'absence_rate': rate})

    @http.route('/my/children/<int:student_id>/exams', type='http', auth='user', website=True)
    def child_exams(self, student_id, **kw):
        student = self._student_for_parent(student_id)
        exams = request.env['school.exams'].sudo().search([('student_id', '=', student.id)], order='exam_date desc')
        return request.render('school_portal_management.portal_child_exams', {'student': student, 'exams': exams})

    @http.route('/my/children/<int:student_id>/dashboard', type='http', auth='user', website=True)
    def child_dashboard(self, student_id, **kw):
        student = self._student_for_parent(student_id)
        Homework = request.env['school.homework'].sudo()
        Exam = request.env['school.exams'].sudo()
        Attendance = request.env['school.attendance'].sudo()
        homework = Homework.search([('student_id', '=', student.id)])
        graded_homework = homework.filtered(lambda h: h.state == 'graded')
        exams = Exam.search([('student_id', '=', student.id)])
        attendance = Attendance.search([('student_id', '=', student.id)])
        absent = attendance.filtered(lambda a: a.state == 'absent')
        values = {
            'student': student,
            'homework_count': len(homework),
            'submitted_count': len(homework.filtered(lambda h: h.state in ('submitted', 'graded'))),
            'late_count': len(homework.filtered(lambda h: h.state == 'late')),
            'homework_average': (sum(graded_homework.mapped('grade')) / len(graded_homework)) if graded_homework else 0,
            'exam_average': ((sum((e.student_grade / e.max_grade) * 100 for e in exams if e.max_grade) / len(exams)) if exams else 0),
            'absence_rate': (len(absent) / len(attendance) * 100) if attendance else 0,
            'latest_homework': homework.sorted(key=lambda h: h.due_date or '', reverse=True)[:5],
            'latest_exams': exams.sorted(key=lambda e: e.exam_date or '', reverse=True)[:5],
        }
        return request.render('school_portal_management.portal_child_dashboard', values)
